<html>
<head>
<title> Second Page </title>
</head>
<body>
<?php $sec="First page";
$id =$_GET["id"];
$cmp =$_GET["company"];

 ?>

<a href= "first_page.php" >  Click here for    <?php 
echo $sec;
echo "id = $id";
echo " Companyy = $cmp"; 

?>   </a>
</body>
</html>