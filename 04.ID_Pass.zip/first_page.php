<html>
<head>
<title> First Page </title>

</head>


<body>
<?php 
$sec="Second page";
$id=2;
$company="EIC";
?>
<a href= "second_page.php?id= <?php echo $id;?> &company= <?php echo $company;?>" >  Click here for <?php echo $sec ;?> </a>
</body>
</html>