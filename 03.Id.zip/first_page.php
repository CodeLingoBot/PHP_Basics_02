<html>
<head>
<title> First Page </title>

</head>


<body>

This is First Page
<?php 
$sec="Second page";
$id=2; 
?>
<a href= "second_page.php?id=<?php echo $id ; ?> " >  Click here for <?php echo $sec ; ?>   </a>
</body>
</html>