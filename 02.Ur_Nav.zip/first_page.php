<html>
<head>
<title> First Page </title>

</head>


<body>

This is First Page
<?php $sec="Second page"  ?>
<a href= "second_page.php" >  Click here for <?php echo $sec ; ?>   </a>
</body>
</html>