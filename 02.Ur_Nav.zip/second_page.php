<html>
<head>
<title> Second Page </title>

</head>


<body>

This is Second Page
<?php $sec="First page"  ?>
<a href= "first_page.php" >  Click here for <?php echo $sec ; ?>   </a>
</body>
</html>