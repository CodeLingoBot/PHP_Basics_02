
<?php 
include 'include.php';

?>


Above part is included
<p> and this is Not included part. </p>

</body>
</html>