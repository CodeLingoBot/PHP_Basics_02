
<!DOCTYPE html>
<html>
<body>

<?php
$str = ' Included php file ';
echo htmlentities($str);
echo "Hello Include";
print_r("");
?>

