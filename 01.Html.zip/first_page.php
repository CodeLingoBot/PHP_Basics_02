<html>
<head>
<title> First Page </title>

</head>


<body>

First Page
<a href= "second_page.php" >  Click here for second page</a>
</body>
</html>