<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>URL Encoder</title>
</head>
<body>
<?php
echo '<a href="http://example.com/department_list_script/',
    rawurlencode('sales and marketing/Miami'), '">';

?>

<?php
$str = "This is some <b>bold</b> text.";
echo htmlspecialchars($str);
?>

</body> 


 
</html>