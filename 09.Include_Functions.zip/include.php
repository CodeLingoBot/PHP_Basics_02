
<!DOCTYPE html>
<html>
<body>

<?php
 function printdata($idata)
 {
     return "Hello $idata";
 }
?>

