
<?php 
include 'include.php';
echo printdata("PHP");
?>



</body>
</html>